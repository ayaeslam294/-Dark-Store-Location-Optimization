# Dark Store Optimization System — UI/UX Prototype

This folder contains a **modern, professional analytics dashboard UI** (desktop-first) for an AI & GIS-based system.

## Screens

- `dashboard.html` — Home / Dashboard
- `analysis.html` — Data Analysis
- `optimization.html` — Optimization Results
- `reports.html` — Reports

## How to view

Open `index.html` (or any screen above) in your browser.

## Design system (high level)

- Light theme: white + light gray surfaces
- Primary: dark blue
- Secondary: light blue + green (plus purple/orange for KPI variety)
- Rounded cards, smooth shadows, consistent spacing
- Inter font + line SVG icons

