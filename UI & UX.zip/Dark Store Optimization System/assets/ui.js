// Minimal UI interactions for static prototype
(function () {
  const switches = document.querySelectorAll("[data-switch]");
  switches.forEach((el) => {
    el.addEventListener("click", () => {
      el.classList.toggle("on");
      const key = el.getAttribute("data-switch") || "";
      const isOn = el.classList.contains("on");
      document.documentElement.dataset[key] = isOn ? "on" : "off";
    });
  });

  // Active link highlighting (topnav + sidebar)
  const path = (location.pathname.split("/").pop() || "index.html").toLowerCase();
  const setActive = (selector) => {
    document.querySelectorAll(selector).forEach((a) => {
      const href = (a.getAttribute("href") || "").toLowerCase();
      if (!href) return;
      const match = href.endsWith(path);
      a.classList.toggle("active", match);
    });
  };
  setActive(".topnav a.navlink");
  setActive(".sidebar a.side-item");
})();

